## Vite_React_Tailwind_ReactRouter_JS_Starter

React Starter template with
- Vite  
- Tailwind 
- React Router
