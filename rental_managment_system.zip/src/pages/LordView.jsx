import React from 'react'

const LordView = () => {
  return (
    <div>LordView</div>
  )
}

export default LordView